
package g11.apprestaurante;

import java.util.Scanner;


public class AppRestaurante {
    
    

    public static void main(String[] args) {
        ini.inicio();
    }
    public static void ver() {
        Scanner menu = new Scanner(System.in);
        int ham=8000,hamdob=10000,hamtri=13000,jugo1=4000,jugo2=4500,jugo3=5000;
        System.out.println("Bienvenido a nuestro restaurante, este es nuestro menu:");
        System.out.println("1. Hamburguesa sencilla: " + ham);
        System.out.println("2. Hamburguesa doble: " + hamdob);
        System.out.println("3. Hamburguesa triple " + hamtri);
        System.out.println("Bebidas: ");
        System.out.println("1. Agua " + jugo1);
        System.out.println("2. Gaseosa " + jugo2);
        System.out.println("3. Agua " + jugo3);
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("Por favor reinicie el programa si desea salir ");
        
    }

    public static void escoger() {
        Scanner menu = new Scanner(System.in);
        int ham=8000,hamdob=10000,hamtri=13000,jugo1=4000,jugo2=4500,jugo3=5000,b,d,e,f,c_ham=0,c_hambob=0,c_hamtrip=0,c_jug1=0,c_jug2=0,c_jug3=0,total;
        System.out.println("Elige que comida deseas agregar uno por uno:");
        System.out.println("1. Haburgesa        $8.000:");
        System.out.println("2. Haburgesa doble  $10.000:");
        System.out.println("3. Haburgesa triple $13.000:");
        b=menu.nextInt();
        if (b==1){
            System.out.println("Cuantas hamburguesas deseas:?");
            int c = menu.nextInt();
            c_ham=c;
        } if (b==2){
            System.out.println("Cuantas hamburguesas dobles deseas:?");
            int c = menu.nextInt();
            c_hambob=c;
        } if (b==3){
            System.out.println("Cuantas hamburguesas triples deseas:?");
            int c = menu.nextInt();
            c_hamtrip=c;
        }
        
        System.out.println("Deseas algo de tomar?");
        System.out.println("1. Si");
        System.out.println("1. No");
        d=menu.nextInt();
        if (d==1){
            System.out.println("Que jugo deseas?");
            System.out.println("1. Agua         $4000");
            System.out.println("2. Gaseosa      $4500");
            System.out.println("3. Jugo Natural $5000");
            e=menu.nextInt();
            if(e==1){
                System.out.println("Cuantas aguas deseas?");
                f=menu.nextInt();
                c_jug1=f;
            } if(e==2){
                System.out.println("Cuantas gaseosas deseas?");
                f=menu.nextInt();
                c_jug2=f;
            } if(e==3){
                System.out.println("Cuantos jugos deseas?");
                f=menu.nextInt();
                c_jug1=f;
            }
        } if (d==2){
            System.out.println("Vale, no hay problema");
        }
        
        total=((c_ham*ham)+(c_hambob*hamdob)+(c_hamtrip*hamtri)+(c_jug1*jugo1)+(c_jug2*jugo2)+(c_jug3*jugo3));
        System.out.println("El precio total de tu pedido fue: $" +total);
        
    }

    
}
