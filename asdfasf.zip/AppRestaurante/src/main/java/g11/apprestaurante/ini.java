
package g11.apprestaurante;

import java.util.Scanner;


public class ini {
    
    public static void inicio(){
        Scanner menu = new Scanner(System.in);
        int a;
        System.out.println("Hola buenos dias, por favor elige que deseas hacer");
        System.out.println("1. Ver menu del restaurante");
        System.out.println("2. Realizar pedido");
        a=menu.nextInt();
        if(a==1) {
            AppRestaurante.ver();
        }
         else if (a==2) {
            AppRestaurante.escoger();
         } else if (a==3) {
             
         } else { }
        
    }
    
}
